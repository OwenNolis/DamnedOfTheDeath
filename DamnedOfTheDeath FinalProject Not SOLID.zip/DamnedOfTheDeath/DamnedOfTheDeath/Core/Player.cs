﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using DamnedOfTheDeath.Core.animations.player;
using DamnedOfTheDeath.Core.input;
using DamnedOfTheDeath.Core.movement;
using DamnedOfTheDeath.UI;
using DamnedOfTheDeath.Utility.animation;
using DamnedOfTheDeath.Utility.collisions;
using DamnedOfTheDeath.Utility.statemachine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace DamnedOfTheDeath.Core
{
    public class Player
    {
    } 
}
