﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DamnedOfTheDeath.Core.animations.enemy1;
using DamnedOfTheDeath.Core.enemies;
using DamnedOfTheDeath.Map;
using DamnedOfTheDeath.Map.tiles;
using Microsoft.Xna.Framework;
using AttackState = DamnedOfTheDeath.Core.animations.player.AttackState;
using HurtState = DamnedOfTheDeath.Core.animations.player.HurtState;

namespace DamnedOfTheDeath.Core
{
    public class PlayerCollisionManager
    {
    }
}
