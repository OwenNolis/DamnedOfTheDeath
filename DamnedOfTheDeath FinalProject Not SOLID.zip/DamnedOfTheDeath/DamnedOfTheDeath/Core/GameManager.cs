﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DamnedOfTheDeath.Core.gameStates;
using DamnedOfTheDeath.Map;
using DamnedOfTheDeath.Utility.statemachine;
using Microsoft.Xna.Framework;

namespace DamnedOfTheDeath.Core
{
    public class GameManager
    {
    }
}
