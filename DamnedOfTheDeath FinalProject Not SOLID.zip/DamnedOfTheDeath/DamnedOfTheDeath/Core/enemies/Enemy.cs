﻿using DamnedOfTheDeath.Core;
using DamnedOfTheDeath.Core.movement;
using DamnedOfTheDeath.Utility;
using DamnedOfTheDeath.Utility.collisions;
using DamnedOfTheDeath.Utility.statemachine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace GameDevProject.Core.enemies;

public abstract class Enemy
{
}