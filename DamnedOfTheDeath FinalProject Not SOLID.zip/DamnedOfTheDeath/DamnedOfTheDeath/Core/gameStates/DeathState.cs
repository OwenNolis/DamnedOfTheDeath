﻿using System;
using DamnedOfTheDeath.Core.gameStates;
using DamnedOfTheDeath.Core;
using DamnedOfTheDeath.UI;
using DamnedOfTheDeath.Utility.statemachine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace DamnedOfTheDeath.Core.gameStates;

public class DeathState : GameState
{
}