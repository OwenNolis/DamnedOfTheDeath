﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace DamnedOfTheDeath
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        private Texture2D _spriteSheet;
        private Vector2 _position;
        private float _maxSpeed = 300f;
        private float _acceleration = 300f;
        private float _deceleration = 500f;
        private float _jumpSpeed = -500f; // Initial speed for jumping
        private float _gravity = 800f; // Gravity strength
        private bool _isJumping = false;
        private bool _isGrounded = true;
        private bool _isAttacking = false;
        private int _frame;
        private double _timeSinceLastFrame;
        private double _millisecondsPerFrame = 100;

        private int _frameWidth;
        private int _frameHeight;

        private Vector2 _velocity;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // Set the initial position of the sprite
            _position = new Vector2(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2);
            _velocity = Vector2.Zero;
            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // Load the sprite sheet
            _spriteSheet = Content.Load<Texture2D>("GoblinMechRiderSpriteSheet");

            // Calculate frame dimensions
            _frameWidth = _spriteSheet.Width / 8; // 8 columns in the movement row
            _frameHeight = _spriteSheet.Height / 5; // 5 rows
        }

        protected override void Update(GameTime gameTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            var delta = (float)gameTime.ElapsedGameTime.TotalSeconds;

            // Handle input for movement
            var direction = Vector2.Zero;
            if (Keyboard.GetState().IsKeyDown(Keys.Left))
            {
                direction.X = -1;
            }
            else if (Keyboard.GetState().IsKeyDown(Keys.Right))
            {
                direction.X = 1;
            }

            // Handle attacking
            if (Keyboard.GetState().IsKeyDown(Keys.Space) && !_isAttacking)
            {
                _isAttacking = true;
                _frame = 0; // Start from the first frame of the attack animation
            }

            // Handle jumping
            if (Keyboard.GetState().IsKeyDown(Keys.Up) && _isGrounded && !_isJumping)
            {
                _velocity.Y = _jumpSpeed;
                _isJumping = true;
                _isGrounded = false;
            }

            if (_isAttacking)
            {
                AnimateAttack(gameTime);
            }
            else
            {
                // Update horizontal velocity and animation
                if (direction.X != 0)
                {
                    _velocity.X += direction.X * _acceleration * delta;
                    _velocity.X = MathHelper.Clamp(_velocity.X, -_maxSpeed, _maxSpeed);
                    AnimateMovement(gameTime);
                }
                else
                {
                    if (_velocity.X > 0)
                    {
                        _velocity.X -= _deceleration * delta;
                        if (_velocity.X < 0) _velocity.X = 0;
                    }
                    else if (_velocity.X < 0)
                    {
                        _velocity.X += _deceleration * delta;
                        if (_velocity.X > 0) _velocity.X = 0;
                    }

                    if (!_isJumping)
                    {
                        _frame = 0; // Reset to idle frame if no movement
                    }
                }
            }

            if (_isJumping)
            {
                // Apply gravity while jumping
                _velocity.Y += _gravity * delta;
            }

            // Update position
            _position.X += _velocity.X * delta;
            _position.Y += _velocity.Y * delta;

            // Simulate ground collision
            if (_position.Y >= GraphicsDevice.Viewport.Height - _frameHeight)
            {
                _position.Y = GraphicsDevice.Viewport.Height - _frameHeight;
                _velocity.Y = 0;
                _isGrounded = true;
                _isJumping = false;
            }

            base.Update(gameTime);
        }

        private void AnimateMovement(GameTime gameTime)
        {
            _timeSinceLastFrame += gameTime.ElapsedGameTime.TotalMilliseconds;

            if (_timeSinceLastFrame >= _millisecondsPerFrame)
            {
                _frame++;
                if (_frame > 7) // There are 8 frames in the movement row
                    _frame = 0;

                _timeSinceLastFrame = 0;
            }
        }

        private void AnimateAttack(GameTime gameTime)
        {
            _timeSinceLastFrame += gameTime.ElapsedGameTime.TotalMilliseconds;

            if (_timeSinceLastFrame >= _millisecondsPerFrame)
            {
                _frame++;
                if (_frame > 6) // There are 7 frames in the attack row
                {
                    _frame = 0;
                    _isAttacking = false; // End attack animation
                }

                _timeSinceLastFrame = 0;
            }
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            _spriteBatch.Begin();

            Rectangle sourceRectangle;

            if (_isAttacking)
            {
                // Use the attack animation frames (third row)
                sourceRectangle = new Rectangle(_frame * _frameWidth, _frameHeight * 2, _frameWidth, _frameHeight); // Attack animation
            }
            else if (_isJumping)
            {
                // Use the same animation frame during jump if moving
                if (_velocity.X != 0)
                {
                    sourceRectangle = new Rectangle(_frame * _frameWidth, _frameHeight, _frameWidth, _frameHeight); // Movement animation
                }
                else
                {
                    sourceRectangle = new Rectangle(0, 0, _frameWidth, _frameHeight); // Default frame or idle frame during jump
                }
            }
            else
            {
                // Calculate the source rectangle for the current frame in the movement row (index 1)
                sourceRectangle = new Rectangle(_frame * _frameWidth, _frameHeight, _frameWidth, _frameHeight);
            }

            // Draw the current frame
            _spriteBatch.Draw(_spriteSheet, _position, sourceRectangle, Color.White);

            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}