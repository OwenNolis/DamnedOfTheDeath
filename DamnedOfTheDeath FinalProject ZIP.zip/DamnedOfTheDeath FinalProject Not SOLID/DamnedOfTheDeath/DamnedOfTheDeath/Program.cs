﻿
using var game = new DamnedOfTheDeath.Game1();
game.Run();
