﻿using DamnedOfTheDeath.Core;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace GameDevProject.Core.enemies;

public abstract class Enemy
{
}